﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;    


namespace SSO.Models
{
    public class SqlDbContext : DbContext
    {
        public SqlDbContext()
            : base("name=SqlConnection")
        {
        }
        public DbSet<usermaster> usermasters { get; set; }    
    }
}
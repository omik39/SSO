﻿using SSO.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Fluentx.Mvc;
namespace SSO.Controllers
{
    [UserAuthenticationFilter]
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        public  ActionResult App1()
        {
            Dictionary<string, object> postData = new Dictionary<string, object>();
            postData.Add("SessionKey", Session["Sessionkey"].ToString());
            return this.RedirectAndPost("http://localhost:42679/Home/Index", postData);
        }

        public ActionResult App2()
        {
            Dictionary<string, object> postData = new Dictionary<string, object>();
            postData.Add("SessionKey", Session["Sessionkey"].ToString());
            return this.RedirectAndPost("http://localhost:42686/Default.aspx", postData);
        }

    }
}
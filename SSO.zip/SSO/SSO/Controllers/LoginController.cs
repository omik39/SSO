﻿using SSO.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SSO.Controllers
{
    public class LoginController : Controller
    {
        // GET: Login
        [HttpGet]
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(usermaster user)
        {
            if (ModelState.IsValid)
            {
                using (var context = new SqlDbContext())
                {
                    usermaster users = context.usermasters
                                       .Where(u => u.username == user.username && u.password == user.password)
                                       .FirstOrDefault();

                    if (users != null)
                    {
                        Session["UserName"] = users.username;
                        Session["UserID"] = users.ID;

                        using (SqlConnection connection = new SqlConnection(@"Data Source=SHAIKHDAWOOD\LOCAL;Initial Catalog=SSO;User ID=sa;Password=sa@123"))
                        {
                            var command = new SqlCommand("sessiondml", connection);
                            command.CommandType = CommandType.StoredProcedure;
                            command.Parameters.AddWithValue("@userid", Session["UserID"].ToString());
                            connection.Open();
                            Session["Sessionkey"]= command.ExecuteScalar().ToString();
                            connection.Close();
                        }
                        return RedirectToAction("Index", "Home");
                    }
                    else
                    {
                        ModelState.AddModelError("", "Invalid User Name or Password");
                        return View(user);
                    }
                }
            }
            else
            {
                return View(user);
            }  
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LogOff()
        {
            Session["UserName"] = string.Empty;
            Session["UserID"] = null;
            return RedirectToAction("Index", "Home");
        }  
    }
}